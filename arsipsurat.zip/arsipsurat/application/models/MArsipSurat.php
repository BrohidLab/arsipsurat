<?php
	
	defined('BASEPATH') OR exit('No direct script access allowed');

	/**
	 * 
	 */
	class MArsipSurat extends CI_Model
	{
		
		function __construct()
		{
			parent::__construct();
		}

		function proses_login($array){
			return $this->db->get_where('tbl_user',$array);
		}

		function datapengguna(){
			return $this->db->get('tbl_user');
		}

		function save_user($array){
			return $this->db->insert('tbl_user', $array);
		}

		function get_datauser($id){
			$this->db->where('id_user', $id);
			return $this->db->get("tbl_user");
		}

		function editpengguna($array, $id){
			$this->db->where('id_user', $id);
			return $this->db->update('tbl_user', $array);
		}

		function delete_user($id_user){
			$this->db->where('id_user', $id_user);
			return $this->db->delete('tbl_user');
		}

		function databagian(){
			return $this->db->get('tbl_bagian');
		}

		function get_databagian($id){ // bikin function ini dan taruh di bawah databagian
			$this->db->where('id_bagian', $id);
			return $this->db->get('tbl_bagian');
		}

		function simpan_bagian($array){
			return $this->db->insert('tbl_bagian', $array);
		}

		function edit_bagian($array, $id){
			$this->db->where('id_bagian', $id);
			return $this->db->update('tbl_bagian', $array);
		}

		function delete_bagian($id){
			$this->db->where('id_bagian', $id);
			return $this->db->delete('tbl_bagian');
		}

		function datas_masuk(){
			$nama = $this->session->userdata('nama');
			return $this->db->query("SELECT * FROM tbl_sm WHERE pengirim = '$nama' OR penerima = '$nama'");
		}

		function kirims_masuk($datas_masuk){
			return $this->db->insert('tbl_sm', $datas_masuk);
		}

		function get_datas_masuk($id){
			$this->db->where('id_sm', $id);
			return $this->db->get('tbl_sm');
		}

		function edits_masuk($array, $id){
			$this->db->where('id_sm', $id);
			return $this->db->update('tbl_sm', $array);
		}

		function deletes_masuk($id){
			$this->db->where('id_sm', $id);
			return $this->db->delete('tbl_sm');
		}

		function datas_keluar(){
			$nama = $this->session->userdata('nama');
			return $this->db->query("SELECT * FROM tbl_sk WHERE pengirim = '$nama' OR penerima = '$nama'");
		}

		function kirims_keluar($datas_masuk){
			return $this->db->insert('tbl_sk', $datas_masuk);
		}

		function get_datas_keluar($id){
			$this->db->where('id_sk', $id);
			return $this->db->get('tbl_sk');
		}

		function edits_keluar($array, $id){
			$this->db->where('id_sk', $id);
			return $this->db->update('tbl_sk', $array);
		}

		function deletes_keluar($id){
			$this->db->where('id_sk', $id);
			return $this->db->delete('tbl_sk');
		}

		function data_memo(){
			$this->db->where('id_user', $this->session->userdata('id_user'));
			return $this->db->get('tbl_memo');
		}

		function save_memo($array){
			return $this->db->insert('tbl_memo', $array);
		}

		function chatting($id){
			return $this->db->query("SELECT * FROM tbl_user_chat INNER JOIN tbl_user ON tbl_user_chat.id_penerima = tbl_user.id_user where tbl_user_chat.id_pengirim = '$id'");
		}

		function detailchatting($id_pengirim, $id_penerima){
			return $this->db->query("SELECT * FROM tb_chatting INNER JOIN tbl_user ON tb_chatting.pengirim = tbl_user.id_user WHERE tb_chatting.pengirim = '$id_pengirim' AND tb_chatting.penerima = '$id_penerima' OR tb_chatting.pengirim = '$id_penerima' AND tb_chatting.penerima = '$id_pengirim' ORDER BY tanggal ASC");
		}

		function simpan_chatting($array){
			return $this->db->insert('tb_chatting', $array);
		}

		function validasi_user_chat($id_penerima, $id_pengirim){
			return $this->db->query("SELECT * FROM tbl_user_chat where id_penerima = '$id_penerima' AND id_pengirim = '$id_pengirim'");
		}

		function save_user_chat($array){
			return $this->db->insert('tbl_user_chat', $array);
		}

		function lap_datas_masuk($tanggal_awal, $tanggal_akhir){

			$id_user = $this->session->userdata('id_user');
			return $this->db->query("SELECT * FROM tbl_sm WHERE id_user = '$id_user' AND tgl_sm BETWEEN '$tanggal_awal' AND '$tanggal_akhir' ");;
		}

		function lap_datas_keluar($tanggal_awal, $tanggal_akhir){

			$id_user = $this->session->userdata('id_user');
			return $this->db->query("SELECT * FROM tbl_sk WHERE id_user = '$id_user' AND tgl_sk BETWEEN '$tanggal_awal' AND '$tanggal_akhir'");;
		}

		function simpan_ns($array){
			return $this->db->insert('tb_nomer_surat', $array);
		}

		function datans(){
			$id_user = $this->session->userdata('id_user'); // ganti script seperti ini
			$this->db->where('id_create', $id_user);
			return $this->db->get('tb_nomer_surat');
		}

		function get_data_ns($id){
			$this->db->where('id_nomer_surat', $id);
			return $this->db->get('tb_nomer_surat');
		}

		function edit_ns($array, $id){
			$this->db->where('id_nomer_surat', $id);
			return $this->db->update('tb_nomer_surat', $array);
		}

		function delete_ns($id){
			$this->db->where('id_nomer_surat', $id);
			return $this->db->delete('tb_nomer_surat');
		}

		function get_nomer_surat_sm(){
			$id_user = $this->session->userdata('id_user');
			return $this->db->query("SELECT * FROM tb_nomer_surat WHERE jenis_ns = 'sm' AND id_create = '$id_user'"); // ganti script seperti ini
		}

		function get_nomer_surat_sk(){
			$id_user = $this->session->userdata('id_user');
			return $this->db->query("SELECT * FROM tb_nomer_surat WHERE jenis_ns = 'sk' AND id_create = '$id_user'"); // ganti script seperti ini
		}

	}

?>