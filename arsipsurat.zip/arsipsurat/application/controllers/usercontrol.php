<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
	/**
	 * 
	 */
	class Usercontrol extends CI_Controller
	{
		
		function __construct()
		{
			parent::__construct();
		}

		function index(){
			$page = $this->uri->segment(3);
			if (empty($page)) {
				$page = "dashboard";
			}
			$data['jumlah_userdata'] = $this->MArsipSurat->datapengguna()->num_rows();
				$data['jumlah_smasuk'] = $this->MArsipSurat->datas_masuk()->num_rows();
				$data['jumlah_skeluar'] = $this->MArsipSurat->datas_keluar()->num_rows();
			$data['page'] = $page;
			$this->load->view('web/berandahome', $data);
		}

		function homepage(){
			$page = $this->uri->segment(3);
			if (empty($page)) {
				$page = "dashboard";
			}
			$data['jumlah_userdata'] = $this->MArsipSurat->datapengguna()->num_rows();
				$data['jumlah_smasuk'] = $this->MArsipSurat->datas_masuk()->num_rows();
				$data['jumlah_skeluar'] = $this->MArsipSurat->datas_keluar()->num_rows();
			$data['page'] = $page;

			if ($page == "dashboard") {
				$data['jumlah_userdata'] = $this->MArsipSurat->datapengguna()->num_rows();
				$data['jumlah_smasuk'] = $this->MArsipSurat->datas_masuk()->num_rows();
				$data['jumlah_skeluar'] = $this->MArsipSurat->datas_keluar()->num_rows();
				$this->load->view('web/berandahome', $data);
			}else if ($page == "pengguna") {
				$data['datauser'] = $this->MArsipSurat->datapengguna()->result();
				$this->load->view('web/berandahome', $data);
			}else if ($page == "tambahpengguna") {
				$this->load->view('web/berandahome', $data);
			}else if ($page == "editpengguna") {
				$id = $this->uri->segment(4);
				$data['arrayuser'] = $this->MArsipSurat->get_datauser($id)->row_array();
				$this->load->view('web/berandahome', $data);
			}else if ($page == "view_pengguna") {
				$id = $this->uri->segment(4);
				$data['arrayuser'] = $this->MArsipSurat->get_datauser($id)->row_array();
				$this->load->view('web/berandahome', $data);
			}else if ($page == "bagian") {
				$data['databagian'] = $this->MArsipSurat->databagian()->result(); // ini untuk 
				$this->load->view('web/berandahome', $data);
			}else if ($page == "tambahbagian") {
				$this->load->view('web/berandahome', $data);
			}else if ($page == "editbagian") { // tambahkan data ini di bawah tambah bagian
				$id = $this->uri->segment(4);
				$data['arraybagian'] = $this->MArsipSurat->get_databagian($id)->row_array();
				$this->load->view('web/berandahome', $data);
			}else if ($page == "s_masuk") {
				$data['datasm'] = $this->MArsipSurat->datas_masuk()->result();
				$this->load->view('web/berandahome', $data);
			}else if ($page == "kirims_masuk") {
				$jum = $this->MArsipSurat->datas_masuk();
				$type_ns = $this->MArsipSurat->get_nomer_surat_sm()->row();
				$jum_ns = $this->MArsipSurat->get_nomer_surat_sm()->num_rows(); // tambahkan script seperti ini

				if ($jum->num_rows() == 0) {
					if ($jum_ns == 0) {
						$kodenomer_surat = "";
					}else{
					 	$kodenomer_surat = $type_ns->nomer_surat;
					}
				}else{
					$datans = $jum->row();
					$kod = $datans->no_surat;
					$valkode = substr($kod, 0,3) + 1;
					
					$kodenomer_surat = $valkode.substr($type_ns->nomer_surat, 3);
				}
				$data['datans_sm'] = $kodenomer_surat;
				$this->load->view('web/berandahome', $data);
			}else if ($page == "edits_masuk") {
				$id = $this->uri->segment(4);
				$data['arraysurat'] = $this->MArsipSurat->get_datas_masuk($id)->row_array();
				$this->load->view('web/berandahome', $data);
			}else if ($page == "s_keluar") {
				$data['datasm'] = $this->MArsipSurat->datas_keluar()->result();
				$this->load->view('web/berandahome', $data);
			}else if ($page == "kirims_keluar") {
				$jum = $this->MArsipSurat->datas_keluar();
				$type_ns = $this->MArsipSurat->get_nomer_surat_sk()->row();
				$jum_ns = $this->MArsipSurat->get_nomer_surat_sk()->num_rows(); // ganti seperti script ini
				if ($jum->num_rows() == 0) {
					if ($jum_ns == 0) {
						$kodenomer_surat = "";
					}else{
						$kodenomer_surat = $type_ns->nomer_surat;
					}
				}else{
					$datans = $jum->row();
					$kod = $datans->no_surat;
					$valkode = substr($kod, 0,3) + 1;
					
					$kodenomer_surat = $valkode.substr($type_ns->nomer_surat, 3);
				}
				$data['datans_sk'] = $kodenomer_surat;
				$this->load->view('web/berandahome', $data);
			}else if ($page == "edits_keluar") {
				$id = $this->uri->segment(4);
				$data['arraysurat'] = $this->MArsipSurat->get_datas_keluar($id)->row_array();
				$this->load->view('web/berandahome', $data);
			}else if ($page == "memo") {
				$data['datamemo'] = $this->MArsipSurat->data_memo()->result();
				$this->load->view('web/berandahome', $data);
			}else if ($page == "tambah_memo") {
				$this->load->view('web/berandahome', $data);
			}else if ($page == "chatting") {
				$id = $this->session->userdata('id_user');
				$data['datachatting'] = $this->MArsipSurat->chatting($id)->result();
				$this->load->view('web/berandahome', $data);
			}else if ($page == "detail_chat") {
				$id_pengirim = $this->session->userdata('id_user');
				$id_penerima = $this->uri->segment(4);
				$data['datachatting'] = $this->MArsipSurat->detailchatting($id_pengirim, $id_penerima)->result();
				$this->load->view('web/berandahome', $data);
			}else if ($page == "tambah_chat") {
				$this->load->view('web/berandahome', $data);
			}else if ($page == "laporan_surat_masuk") {
				$this->load->view('web/berandahome', $data);
			}else if ($page == "view_laporan_surat_masuk") {
				$tanggal_awal = $this->uri->segment(4);
				$tanggal_akhir = $this->uri->segment(5);
				$data['datasm'] = $this->MArsipSurat->lap_datas_masuk($tanggal_awal, $tanggal_akhir)->result();
				$this->load->view('web/berandahome', $data);
			}else if ($page == "laporan_surat_keluar") {
				$this->load->view('web/berandahome', $data);
			}else if ($page == "view_laporan_surat_keluar") {
				$tanggal_awal = $this->uri->segment(4);
				$tanggal_akhir = $this->uri->segment(5);
				$data['datasm'] = $this->MArsipSurat->lap_datas_keluar($tanggal_awal, $tanggal_akhir)->result();
				$this->load->view('web/berandahome', $data);
			}else if ($page == "nomer_surat") {
				$data['datans'] = $this->MArsipSurat->datans()->result();
				$this->load->view('web/berandahome', $data);
			}else if ($page == "tambah_ns") {
				$this->load->view('web/berandahome', $data);
			}else if ($page == "edit_ns") {
				$id = $this->uri->segment(4);
				$data['arrayns'] = $this->MArsipSurat->get_data_ns($id)->row_array();
				$this->load->view('web/berandahome', $data);
			}
		}

		function sendMailaprrovesm() {
			$pengirim = $this->uri->segment(3);
			$penerima = $this->uri->segment(4);
			$email_pengirim = $this->db->query("SELECT email FROM tbl_user INNER JOIN tbl_sm ON tbl_user.nama_lengkap = tbl_sm.pengirim WHERE tbl_sm.pengirim = '$pengirim'");
			$email_penerima = $this->db->query("SELECT email FROM tbl_user INNER JOIN tbl_sm ON tbl_user.nama_lengkap = tbl_sm.penerima WHERE tbl_sm.penerima = '$penerima'");

	        $ci = get_instance();
	        $ci->load->library('email');
	        $config['protocol'] = "smtp";
	        $config['smtp_host'] = "ssl://smtp.gmail.com";
	        $config['smtp_port'] = "465";
	        $config['smtp_user'] = "ahmadsahhidukiftiyadin@gmail.com";
	        $config['smtp_pass'] = "putra sejati";
	        $config['charset'] = "utf-8";
	        $config['mailtype'] = "html";
	        $config['newline'] = "\r\n";
	        
	        
	        $ci->email->initialize($config);
	 
	        $ci->email->from("penghasiluang100m@gmail.com", "BROHID LAB");
	        $list = array("penghasiluang100m@gmail.com");
	        $ci->email->to($list);
	        $ci->email->subject('Approve Surat Masuk');
	        $ci->email->message('surat yang anda kirim sudah di aprove sama atasan');
	        if ($this->email->send()) {
	            echo 'Email sent.';
	            //$this->db->query("UPDATE tbl_sm set dibaca = 'Sudah di approve' where id_sm = '$id'");
	        } else {
	            show_error($this->email->print_debugger());
	        }
	    }

	    function sendMailaprrovesk() {
			$pengirim = $this->uri->segment(3);
			$penerima = $this->uri->semgent(4);
			$email_pengirim = $this->db->query("SELECT email FROM tbl_user INNER JOIN tbl_sk ON tbl_user.nama_lengkap = tbl_sk.pengirim WHERE tbl_sk.pengirim = '$pengirim'");
			$email_penerima = $this->db->query("SELECT email FROM tbl_user INNER JOIN tbl_sk ON tbl_user.nama_lengkap = tbl_sk.penerima WHERE tbl_sk.penerima = '$penerima'");

	        $ci = get_instance();
	        $ci->load->library('email');
	        $config['protocol'] = "smtp";
	        $config['smtp_host'] = "ssl://smtp.gmail.com";
	        $config['smtp_port'] = "465";
	        $config['smtp_user'] = "ahmadsahhidukiftiyadin@gmail.com";
	        $config['smtp_pass'] = "putra sejati";
	        $config['charset'] = "utf-8";
	        $config['mailtype'] = "html";
	        $config['newline'] = "\r\n";
	        
	        
	        $ci->email->initialize($config);
	 
	        $ci->email->from($email_pengirim, $pengirim);
	        $list = array($email_penerima);
	        $ci->email->to($list);
	        $ci->email->subject('Approve Surat Keluar');
	        $ci->email->message('surat yang anda kirim sudah di aprove sama atasan');
	        if ($this->email->send()) {
	            echo 'Email sent.';
	            $this->db->query("UPDATE tbl_sk set dibaca = 'Sudah di approve' where id_sm = '$id'");
	        } else {
	            show_error($this->email->print_debugger());
	        }
	    }

		function simpan_pengguna(){
			$level = $this->input->post("level");
			$nama_pengguna = $this->input->post("nama_pengguna");
			$katasandi = md5($this->input->post("password"));
			date_default_timezone_set('Asia/Jakarta');
			$tgl = date('d-m-Y H:i:s');

			$datapengguna = array(
								"id_user" => null,
								"username" => $nama_pengguna,
								"password" => $katasandi,
								"nama_lengkap" => $nama_pengguna,
								"email" => "-",
								"alamat" => "-",
								"telp" => "-",
								"pengalaman" => "-",
								"level" => $level,
								"status" => "aktif",
								"tgl_daftar" => $tgl,
								"terakhir_login" => "0000-00-00 00:00:00"
							);
			$simpan = $this->MArsipSurat->save_user($datapengguna);
			if ($simpan) {
				$hasil = array('hasil'=> "berhasil");
				echo json_encode($hasil);
			}else{
				$hasil = array('hasil'=> "gagal");
				echo json_encode($hasil);
			}
		}

		function edit_pengguna(){
			$level = $this->input->post("level");
			$nama_lengkap = $this->input->post("nama_lengkap");
			$email = $this->input->post("email");
			$telp = $this->input->post("telepon");
			$alamat = $this->input->post("alamat");
			$pengalaman = $this->input->post("pengalaman");
			$id_user = $this->input->post("id_user");

			$datapengguna = array(
								"nama_lengkap" => $nama_lengkap,
								"email" => $email,
								"alamat" => $alamat,
								"telp" => $telp,
								"pengalaman" => $pengalaman,
								"level" => $level
							);
			$simpan = $this->MArsipSurat->editpengguna($datapengguna, $id_user);
			if ($simpan) {
				$hasil = array('hasil'=> "berhasil");
				echo json_encode($hasil);
			}else{
				$hasil = array('hasil'=> "gagal");
				echo json_encode($hasil);
			}
		}

		function delete_user($id_user){
			$delete = $this->MArsipSurat->delete_user($id_user);
			if ($delete) {
				redirect('Usercontrol/homepage/pengguna','refresh');
			}else{
				echo "<script>alert('Data gagal dihapus')</script>";
            	redirect('Usercontrol/homepage/pengguna','refresh');
			}
		}

		function simpan_bagian(){
			$nama_bagian = $this->input->post('nama_bagian');
			$id_user = $this->session->userdata('id_user');

			$databagian = array(
							"id_bagian" => null,
							"nama_bagian" => $nama_bagian,
							"id_user" => $id_user
						  );

			$simpan = $this->MArsipSurat->simpan_bagian($databagian);
			if ($simpan) {
				$hasil = array('hasil'=> "berhasil");
				echo json_encode($hasil);
			}else{
				$hasil = array('hasil'=> "gagal");
				echo json_encode($hasil);
			}
		}

		function edit_bagian(){
			$nama_bagian = $this->input->post('nama_bagian');
			$id_bagian = $this->input->post('id_bagian');

			$databagian = array(
							"nama_bagian" => $nama_bagian
						  );

			$simpan = $this->MArsipSurat->edit_bagian($databagian, $id_bagian);
			if ($simpan) {
				$hasil = array('hasil'=> "berhasil");
				echo json_encode($hasil);
			}else{
				$hasil = array('hasil'=> "gagal");
				echo json_encode($hasil);
			}
		}

		//tambah kan script proses di bawah ini
		function delete_bagian($id_bagian){
			$delete = $this->MArsipSurat->delete_bagian($id_bagian);
			if ($delete) {
				redirect('Usercontrol/homepage/bagian','refresh');
			}else{
				echo "<script>alert('Data gagal dihapus')</script>";
            	redirect('Usercontrol/homepage/bagian','refresh');
			}
		}

		function kirims_masuk(){
            $no_surat_masuk = $this->input->post('no_surat_masuk');
            $tanggal_no_asal = $this->input->post('tgl_no_asal');
            $perihal = $this->input->post('perihal');
            $penerima = $this->input->post('penerima');
			$id_user = $this->session->userdata('id_user');
			$pengirim = $this->session->userdata('nama');
            $tanggal = date("Y-m-d");

            if (empty($no_surat_masuk)) {
            	echo "<script>alert('Silahkan isi nomer surat terlebh dahulu..!')</script>";
                echo "<script>document.location='homepage/kirims_masuk'</script>";
            }else{
            
                $config['upload_path'] = "./assets/lampiran_surat_masuk";
                $config['allowed_types'] = "*";
    
                $this->load->library('upload', $config);
    
                if (!$this->upload->do_upload("lampiran")) {
                    $error = $this->upload->display_errors();
                    echo "<script>alert('$error')</script>";
                    echo "<script>document.location='homepage/kirims_masuk'</script>";
                }else{
                    $file = $this->upload->data();
                    $datakirims_masuk = array(
                    				'id_sm' => null,
                    				'no_surat' => $no_surat_masuk,
                    				'tgl_ns' => $tanggal_no_asal,
                    				'no_asal' => $no_surat_masuk,
                    				'tgl_no_asal' => $tgl_no_asal,
                    				'pengirim' => $pengirim,
                    				'penerima' => $penerima,
                    				'perihal' => $perihal,
                    				'token_lampiran' => $file['file_name'],
                    				'dibaca' => 'Belum di baca',
                    				'disposisi' => '0',
                    				'id_user' => $id_user,
                    				'tgl_sm' => $tanggal
                                );
                    $simpan_data = $this->MArsipSurat->kirims_masuk($datakirims_masuk);
                    if ($simpan_data) {
                        echo "<script>alert('Berhasil Tersimpan')</script>";
                        echo "<script>document.location='homepage/s_masuk'</script>";
                    }else{
                        echo "<script>alert('Gagal tersimpan')</script>";
                        echo "<script>document.location='homepage/kirims_masuk'</script>";
                    }
                }
            }
        }

        function edits_masuk(){
        	$id_smasuk = $this->input->post('id_smasuk');
        	$no_surat_masuk = $this->input->post('no_surat_masuk');
            $tanggal_no_asal = $this->input->post('tgl_no_asal');
            $perihal = $this->input->post('perihal');
            $penerima = $this->input->post('penerima');
            $datakirims_masuk = array(
                				'no_surat' => $no_surat_masuk,
                				'tgl_ns' => $tanggal_no_asal,
                				'no_asal' => $no_surat_masuk,
                				'tgl_no_asal' => $tanggal_no_asal,
                				'penerima' => $penerima,
                				'perihal' => $perihal
                            );
            $proses_edit = $this->MArsipSurat->edits_masuk($datakirims_masuk, $id_smasuk);
            if ($proses_edit) {
                echo "<script>alert('Berhasil Tersimpan')</script>";
                echo "<script>document.location='homepage/s_masuk'</script>";
            }else{
                echo "<script>alert('Gagal tersimpan')</script>";
                echo "<script>document.location='homepage/edits_masuk'</script>";
            }
        }

        function deletes_masuk($id){
			$delete = $this->MArsipSurat->deletes_masuk($id);
			if ($delete) {
				redirect('Usercontrol/homepage/s_masuk','refresh');
			}else{
				echo "<script>alert('Data gagal di hapus')</script>";
            	redirect('Usercontrol/homepage/s_masuk','refresh');
			}
		}

		function kirims_keluar(){
            $no_surat_keluar = $this->input->post('no_surat_keluar');
            $tanggal_no_asal = $this->input->post('tgl_no_asal');
            $perihal = $this->input->post('perihal');
            $penerima = $this->input->post('penerima');
            $pengirim = $this->session->userdata('nama');
			$id_user = $this->session->userdata('id_user');
            $tanggal = date("Y-m-d");

            if (empty($no_surat_masuk)) {
            	echo "<script>alert('Silahkan isi nomer surat terlebh dahulu..!')</script>";
                echo "<script>document.location='homepage/kirims_masuk'</script>";
            }else{

	            $config['upload_path'] = "./assets/lampiran_surat_keluar";
	            $config['allowed_types'] = "*";

	            $this->load->library('upload', $config);

	            if (!$this->upload->do_upload("lampiran")) {
	                $error = $this->upload->display_errors();
	                echo "<script>alert('$error')</script>";
	                echo "<script>document.location='page/input_image_news'</script>";
	            }else{
	                $file = $this->upload->data();
	                $datakirims_masuk = array(
	                				'id_sk' => null,
	                				'no_surat' => $no_surat_keluar,
	                				'tgl_ns' => $tanggal_no_asal,
	                				'pengirim' => $pengirim,
	                				'penerima' => $penerima,
	                				'perihal' => $perihal,
	                				'token_lampiran' => $file['file_name'],
	                				'dibaca' => 'Belum di baca',
	                				'disposisi' => '0',
	                				'id_user' => $id_user,
	                				'tgl_sk' => $tanggal
	                            );
	                $simpan_data = $this->MArsipSurat->kirims_keluar($datakirims_masuk);
	                if ($simpan_data) {
	                    echo "<script>alert('Berhasil Tersimpan')</script>";
	                    echo "<script>document.location='homepage/s_keluar'</script>";
	                }else{
	                    echo "<script>alert('Gagal tersimpan')</script>";
	                    echo "<script>document.location='homepage/kirims_keluar'</script>";
	                }
	            }
	        }
        }

        function edits_keluar(){
        	$id_skeluar = $this->input->post('id_skeluar');
        	$no_surat_keluar = $this->input->post('no_surat_keluar');
            $tanggal_no_asal = $this->input->post('tgl_no_asal');
            $perihal = $this->input->post('perihal');
            $penerima = $this->input->post('penerima');
            $datakirims_keluar = array(
                				'no_surat' => $no_surat_keluar,
                				'tgl_ns' => $tanggal_no_asal,
                				'penerima' => $penerima,
                				'perihal' => $perihal
                            );
            $proses_edit = $this->MArsipSurat->edits_keluar($datakirims_keluar, $id_skeluar);
            if ($proses_edit) {
                echo "<script>alert('Berhasil Tersimpan')</script>";
                echo "<script>document.location='homepage/s_keluar'</script>";
            }else{
                echo "<script>alert('Gagal tersimpan')</script>";
                echo "<script>document.location='homepage/edits_keluar'</script>";
            }
        }

        function deletes_keluar($id){
			$delete = $this->MArsipSurat->deletes_keluar($id);
			if ($delete) {
				redirect('Usercontrol/homepage/s_keluar','refresh');
			}else{
				echo "<script>alert('Data gagal di hapus')</script>";
            	redirect('Usercontrol/homepage/s_keluar','refresh');
			}
		}

		function simpan_memo(){
			$judul_memo = $this->input->post("judul_memo");
			$memo = $this->input->post("memo");
			$id_user = $this->session->userdata('id_user');
			$datamemo = array(
								"id_memo" => null,
								"judul_memo" => $judul_memo,
								"memo" => $memo,
								"id_user" => $id_user
							);
			$simpan = $this->MArsipSurat->save_memo($datamemo);
			if ($simpan) {
				$hasil = array('hasil'=> "berhasil");
				echo json_encode($hasil);
			}else{
				$hasil = array('hasil'=> "gagal");
				echo json_encode($hasil);
			}
		}

		function simpan_chatting(){
			$message = $this->input->post('pesan');
			$penerima = $this->input->post('penerima');
			$tanggal = date("Y-m-d");
			$id_user = $this->session->userdata('id_user');

			$databagian = array(
							"id_chat" => null,
							"pengirim" => $id_user,
							"penerima" => $penerima,
							"message" => $message,
							"tanggal" => $tanggal,
							"status" => "sent"
						  );
    		$this->db->query("UPDATE tbl_user_chat set status_chat = 'Belum di baca' where id_penerima = '$id_user' AND id_pengirim = '$penerima'");

			$simpan = $this->MArsipSurat->simpan_chatting($databagian);
			if ($simpan) {
				$hasil = array('hasil'=> "berhasil");
				echo json_encode($hasil);
			}else{
				$hasil = array('hasil'=> "gagal");
				echo json_encode($hasil);
			}
		}

		function save_pesan(){
			$message = $this->input->post('pesan');
			$penerima = $this->input->post('penerima');
			$tanggal = date("Y-m-d");
			$id_user = $this->session->userdata('id_user');

			$datachatting = array(
							"id_chat" => null,
							"pengirim" => $id_user,
							"penerima" => $penerima,
							"message" => $message,
							"tanggal" => $tanggal,
							"status" => "sent"
						  );

			$datauserchat1 = array(
								"id_user_chat" => null,
								"id_penerima" => $penerima,
								"id_pengirim" => $id_user,
								"tanggal" => $tanggal,
								"status_chat" => "Sudah di baca"
							);

			$datauserchat2 = array(
								"id_user_chat" => null,
								"id_penerima" => $id_user,
								"id_pengirim" => $penerima,
								"tanggal" => $tanggal,
								"status_chat" => "Belum di baca"
							);

			$validasi_user = $this->MArsipSurat->validasi_user_chat($penerima, $id_user)->num_rows();

			if ($validasi_user < 1) {
				$this->MArsipSurat->save_user_chat($datauserchat1);
				$this->MArsipSurat->save_user_chat($datauserchat2);
			}


			$simpan = $this->MArsipSurat->simpan_chatting($datachatting);
			if ($simpan) {
				$hasil = array('hasil'=> "berhasil");
				echo json_encode($hasil);
			}else{
				$hasil = array('hasil'=> "gagal");
				echo json_encode($hasil);
			}
		}

		function cetak_sm($tanggal_awal, $tanggal_akhir){
			$data['sql'] = $this->MArsipSurat->lap_datas_masuk($tanggal_awal, $tanggal_akhir);
			$this->load->view('web/content/cetak_sm', $data);
		}

		function cetak_sk($tanggal_awal, $tanggal_akhir){
			$data['sql'] = $this->MArsipSurat->lap_datas_keluar($tanggal_awal, $tanggal_akhir);
			$this->load->view('web/content/cetak_sk', $data);
		}

		function simpan_nomer_surat(){
			$nomer_surat = $this->input->post('nomer_surat');
			$jenis_ns = $this->input->post('jenis_ns');
			$id_user = $this->session->userdata('id_user');
			$tanggal = date("Y-m-d");

			$datans = array(
							"id_nomer_surat" => null,
							"nomer_surat" => $nomer_surat,
							"jenis_ns" => $jenis_ns,
							"tanggal" => $tanggal,
							"id_create" => $id_user
						  );

			$simpan = $this->MArsipSurat->simpan_ns($datans);
			if ($simpan) {
				$hasil = array('hasil'=> "berhasil");
				echo json_encode($hasil);
			}else{
				$hasil = array('hasil'=> "gagal");
				echo json_encode($hasil);
			}
		}

		function edit_nomer_surat(){
			$nomer_surat = $this->input->post('nomer_surat');
			$jenis_ns = $this->input->post('jenis_ns');
			$id_nomer_surat = $this->input->post('id_nomer_surat');
			$id_user = $this->session->userdata('id_user');

			$datans = array(
							"nomer_surat" => $nomer_surat,
							"jenis_ns" => $jenis_ns,
							"id_create" => $id_user
						  );

			$simpan = $this->MArsipSurat->edit_ns($datans, $id_nomer_surat);
			if ($simpan) {
				$hasil = array('hasil'=> "berhasil");
				echo json_encode($hasil);
			}else{
				$hasil = array('hasil'=> "gagal");
				echo json_encode($hasil);
			}
		}

		function delete_ns($id){
			$delete = $this->MArsipSurat->delete_ns($id);
			if ($delete) {
				redirect('Usercontrol/homepage/nomer_surat','refresh');
			}else{
				echo "<script>alert('Data gagal di hapus')</script>";
            	redirect('Usercontrol/homepage/nomer_surat','refresh');
			}
		}
	}

?>