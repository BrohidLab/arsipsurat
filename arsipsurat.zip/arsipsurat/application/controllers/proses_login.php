<?php
defined('BASEPATH') OR exit('No direct script access allowed');

	/**
	 * 
	 */
	class Proses_login extends CI_Controller
	{
		
		function __construct()
		{
			parent::__construct();
		}

		function proses_login(){
			$username = $this->input->post('username');
			$password = md5($this->input->post("password"));

			$data = array(
						'username' => $username,
						'password' => $password
					);

			$proses = $this->MArsipSurat->proses_login($data);
			$qw = $this->db->where('username',$username)->get('tbl_user')->row();
			if ($proses->num_rows() > 0) {

				$data_session = array(
									'nama' => $qw->nama_lengkap,
									'level' => $qw->level,
									'id_user' => $qw->id_user
								);
				$this->session->set_userdata($data_session);
				$hasil = array('hasil'=> "berhasil");
				echo json_encode($hasil);
			}else{
				$hasil = array('hasil'=> "gagal");
				echo json_encode($hasil);
			}
		}

		function logout(){
			$this->session->sess_destroy();
			redirect(site_url(''));
		}
	}

?>