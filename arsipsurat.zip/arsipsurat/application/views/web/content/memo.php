<!-- Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<div class="page-breadcrumb">
    <div class="row align-items-center">
        <div class="col-5">
            <h4 class="page-title">Memo</h4>
            <div class="d-flex align-items-center">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Memo</li>
                    </ol>
                </nav>
            </div>
        </div>

        <div class="col-7">
            <div class="text-right upgrade-btn">
                <a href="<?php echo base_url();?>usercontrol/homepage/tambah_memo" class="btn btn-success text-white"><i class="mdi mdi-account-multiple-plus"></i> Tambah Data</a>
            </div>
        </div>
    </div>
</div>
<!-- ============================================================== -->
<!-- End Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- Container fluid  -->
<!-- ============================================================== -->
<div class="container-fluid">
    <div class="row">
		<div class="col-12">
	        <div class="card">
	            <div class="card-body">
	                <h4 class="card-title">Data Memo</h4>
	                <h6 class="card-subtitle">Masukkan data dengan benar dan.</h6>
	                <div class="col-12">
	            		<table id="example" class="table">
		                    <thead class="thead-light">
		                        <tr>
		                            <th scope="col">No.</th>
		                            <th scope="col">Judul Memo</th>
		                            <th scope="col">Memo</th>
		                        </tr>
		                    </thead>
		                    <tbody>
		                    	<?php
		                    		$no = 0;
		                    		foreach ($datamemo as $array) {
		                    			$no++;
		                    	?>
		                        <tr>
		                            <th scope="row"><?php echo $no;?>.</th>
		                            <td><?php echo $array->judul_memo;?></td>
		                            <td><?php echo $array->memo;?></td>
		                        </tr>
		                    <?php } ?>
		                    </tbody>
		                </table>
	            	</div>
	            </div>
	            	
	                
	        </div>
	    </div>
	</div>
</div>
<!-- ============================================================== -->
<!-- End Container fluid  -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- footer -->
<!-- ============================================================== -->
<footer class="footer text-center">
    All Rights Reserved by Xtreme Admin. Designed and Developed by <a href="https://wrappixel.com">WrapPixel</a>.
</footer>
<!-- ============================================================== -->
<!-- End footer -->
<!-- ============================================================== -->

