<!-- Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<script src="<?php echo base_url();?>assets/assets_home/dist/js/select2.min.js"></script>
<script src="<?php echo base_url();?>assets/assets_home/dist/js/jquery-ui.js"></script>

<div class="page-breadcrumb">
    <div class="row align-items-center">
        <div class="col-5">
            <h4 class="page-title">Kirim Surat Keluar</h4>
            <div class="d-flex align-items-center">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Kirim Surat Keluar</li>
                    </ol>
                </nav>
            </div>
        </div>

        <div class="col-7">
            <div class="text-right upgrade-btn">
                <a href="<?php echo base_url();?>usercontrol/homepage/s_masuk" class="btn btn-danger text-white"><i class="mdi mdi-keyboard-return"></i> Kembali</a>
            </div>
        </div>
    </div>
</div>
<!-- ============================================================== -->
<!-- End Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- Container fluid  -->
<!-- ============================================================== -->
<div class="container-fluid">
    <div class="row">
		<div class="col-10">
	        <div class="card">
	            <div class="card-body">
	                <h4 class="card-title">Data Surat Keluar</h4>
	                <h6 class="card-subtitle">Masukkan data dengan benar dan.</h6>
	            </div>
	            	
	            <div class="card-body">
                    <div class="form-horizontal form-material">
                        <?php echo form_open_multipart('usercontrol/kirims_keluar');?>
                        <div class="form-group">
                            <label class="col-md-6">No. Surat Keluar</label>
                            <div class="col-md-6">
                                <input type="text" placeholder="No. Surat Keluar" class="form-control form-control-line" name="no_surat_keluar" readonly="readonly" value="<?php echo $datans_sk;?>" id="surat_masuk">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="example-email" class="col-md-6">Tanggal</label>
                            <div class="col-md-6">
                                <input type="date" placeholder="Masukkan nama pengguna" class="form-control form-control-line" name="tgl_no_asal" id="tgl_no_asal">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-12">Perihal</label>
                            <div class="col-md-12">
                                <input type="text" name="perihal" class="form-control form-control-line" required="required">
                            </div>
                        </div>
                        <div class="form-group">
                          <label class="control-label col-lg-3">Penerima</label>
                          <div class="col-lg-9">
                                <select class="form-control cari_penerima" name="penerima" id="penerima" required>
                                  <option value="">Pilih</option>
                                  <?php
                                  $this->db->order_by('nama_lengkap', 'ASC');
                                        foreach ($this->db->get('tbl_user')->result() as $baris): ?>
                                            <option value="<?php echo $baris->nama_lengkap; ?>"><?php echo $baris->nama_lengkap; ?></option>
                                  <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-12">*Lampiran</label>
                            <div class="col-md-12">
                                <input type="file" name="lampiran" class="form-control">
                            </div>
                        </div>
                        <div class="form-group m-t-40">
                            <div class="col-sm-12">
                                <button class="btn btn-success" type="submit">Simpan</button>
                            </div>
                        </div>
                        <?php echo form_close();?>
                    </div>
                </div>
	        </div>
	    </div>
	</div>
</div>
<!-- ============================================================== -->
<!-- End Container fluid  -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- footer -->
<!-- ============================================================== -->
<footer class="footer text-center">
    All Rights Reserved by Xtreme Admin. Designed and Developed by <a href="https://wrappixel.com">WrapPixel</a>.
</footer>
<!-- ============================================================== -->
<!-- End footer -->
<!-- ============================================================== -->
