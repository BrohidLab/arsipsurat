<!-- Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<div class="page-breadcrumb">
    <div class="row align-items-center">
        <div class="col-5">
            <h4 class="page-title">Surat Masuk</h4>
            <div class="d-flex align-items-center">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Surat Masuk</li>
                    </ol>
                </nav>
            </div>
        </div>

        <div class="col-7">
            <div class="text-right upgrade-btn">
                <a href="<?php echo base_url();?>usercontrol/homepage/kirims_masuk" class="btn btn-success text-white"><i class="mdi mdi-account-multiple-plus"></i> Kirim Surat</a>
            </div>
        </div>
    </div>
</div>
<!-- ============================================================== -->
<!-- End Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- Container fluid  -->
<!-- ============================================================== -->
<div class="container-fluid">
    <div class="row">
		<div class="col-12">
	        <div class="card">
	            <div class="card-body">
	                <h4 class="card-title">Data Surat Masuk</h4>
	                <h6 class="card-subtitle">Masukkan data dengan benar dan.</h6>
	                <div class="col-12">
	            		<table id="example" class="table">
		                    <thead class="thead-light">
		                        <tr>
		                            <th scope="col">No.</th>
		                            <th scope="col">No. Surat</th>
		                            <th scope="col">Tanggal Surat</th>
		                            <th scope="col">Perihal</th>
		                            <th scope="col">Status</th>
		                            <th scope="col"></th>
		                        </tr>
		                    </thead>
		                    <tbody>
		                    	<?php
		                    		$no = 0;
		                    		foreach ($datasm as $array) {
		                    			$no++;
		                    	?>
		                        <tr>
		                            <th scope="row"><?php echo $no;?></th>
		                            <td><?php echo $array->no_surat;?></td>
		                            <td><?php echo $array->tgl_ns;?></td>
		                            <td><?php echo $array->perihal;?></td>
		                            <td>
		                            	<?php
		                            		if ($array->dibaca == "Belum di baca") {
		                            	?>
		                            	<button class="btn btn-warning">Belum di baca</button>
		                            	<?php
		                            		}else if ($array->dibaca == "Sudah di baca") {
		                            	?>
		                            	<button class="btn btn-info">Sudah di baca</button>
		                            	<?php
		                            		}else{
		                            	?>
		                            	<button class="btn btn-success">Sudah di Approve</button>
		                            	<?php
		                            		}
		                            	?>
		                            </td>
		                            <td>
		                            	<?php 
		                            		if ($this->session->userdata('level') == "s_admin") {
		                            	?>
			                            		<a href="<?php echo base_url();?>usercontrol/homepage/edits_masuk/<?php echo $array->id_sm;?>/view" class="btn btn-info" title="view"><i class="mdi mdi-eye"></i></a>
			                            		<a href="<?php echo base_url();?>usercontrol/homepage/edits_masuk/<?php echo $array->id_sm;?>" class="btn btn-success" title="Edit"><i class="mdi mdi-grease-pencil"></i></a>
				                            	<a href="<?php echo base_url();?>usercontrol/sendMailapprovesm/<?php echo $array->pengirim;?>/<?php echo $array->penerima;?>" class="btn btn-warning" title="Approve"><i class="mdi mdi-check"></i></a>
				                            	<a onClick="javascript: return confirm('Apakah anda yakin ingin menghapusnya ??')" href="<?php echo site_url('usercontrol/deletes_masuk'); ?>/<?php echo $array->id_sm;?>"  class="btn btn-danger" title="Hapus"><i class="mdi mdi-delete"></i></a>
		                            	<?php
		                            		}else if ($this->session->userdata('level') == "user") {
		                            	?>
		                            			<a href="<?php echo base_url();?>usercontrol/homepage/edits_masuk/<?php echo $array->id_sm;?>/view" class="btn btn-info" title="view"><i class="mdi mdi-eye"></i></a>
			                            		<a href="<?php echo base_url();?>usercontrol/homepage/edits_masuk/<?php echo $array->id_sm;?>" class="btn btn-success" title="Edit"><i class="mdi mdi-grease-pencil"></i></a>
		                            	<?php
		                            		}else{
		                            	?>
		                            			<a href="<?php echo base_url();?>usercontrol/homepage/edits_masuk/<?php echo $array->id_sm;?>/view" class="btn btn-info" title="view"><i class="mdi mdi-eye"></i></a>
			                            		<a href="<?php echo base_url();?>usercontrol/homepage/edits_masuk/<?php echo $array->id_sm;?>" class="btn btn-success" title="Edit"><i class="mdi mdi-grease-pencil"></i></a>
				                            	<a href="<?php echo base_url();?>usercontrol/sendMail/<?php echo $array->pengirim;?>/<?php echo $array->penerima;?>" class="btn btn-warning" title="Approve"><i class="mdi mdi-check"></i></a>
		                            	<?php
		                            		}
		                            	?>
		                            	
		                            	
		                            </td>
		                        </tr>
		                    <?php } ?>
		                    </tbody>
		                </table>
	            	</div>
	            </div>
	            	
	                
	        </div>
	    </div>
	</div>
</div>
<!-- ============================================================== -->
<!-- End Container fluid  -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- footer -->
<!-- ============================================================== -->
<footer class="footer text-center">
    All Rights Reserved by Xtreme Admin. Designed and Developed by <a href="https://wrappixel.com">WrapPixel</a>.
</footer>
<!-- ============================================================== -->
<!-- End footer -->
<!-- ============================================================== -->

