<?php
    $id = $this->uri->segment(4);
    $id_user = $this->session->userdata('id_user');
    $this->db->query("UPDATE tbl_user_chat set status_chat = 'Sudah di baca' where id_penerima = '$id' AND id_pengirim = '$id_user'");
?>
<!-- Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<div class="page-breadcrumb">
    <div class="row align-items-center">
        <div class="col-5">
            <h4 class="page-title">Chatting</h4>
            <div class="d-flex align-items-center">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Chatting</li>
                    </ol>
                </nav>
            </div>
        </div>

        <div class="col-7">
            <div class="text-right upgrade-btn">
                            <div class="text-right upgrade-btn">
                <a href="<?php echo base_url();?>usercontrol/homepage/chatting" class="btn btn-danger text-white"><i class="mdi mdi-keyboard-return"></i> Kembali</a>
            </div>
            </div>
        </div>
    </div>
</div>
<!-- ============================================================== -->
<!-- End Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- Container fluid  -->
<!-- ============================================================== -->
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Chatting</h4>
                    <h6 class="card-subtitle">Masukkan data dengan benar dan.</h6>
                    <div class="col-12">
                        <table class="table">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    foreach ($datachatting as $array) {
                                ?>
                                <tr>
                                    <td>
                                        <?php
                                            if ($array->pengirim == "1") {
                                        ?>
                                                <h5 class="btn btn-warning"><?php echo $array->nama_lengkap;?></h5> : <i class="mdi mdi-timer"></i> <?php echo $array->tanggal;?>
                                                <p><?php echo $array->message;?></p>

                                        <?php
                                            }else{
                                        ?>
                                                <h5 class="btn btn-info"><?php echo $array->nama_lengkap;?></h5> : <i class="mdi mdi-timer"></i> <?php echo $array->tanggal;?>
                                                <p><?php echo $array->message;?></p>
                                        <?php
                                            }
                                        ?>
                                    </td>
                                </tr>
                            <?php } ?>
                            </tbody>
                        </table>
                        <hr/>
                        <br/>
                        <div class="form-group">
                            <label for="example-email" class="col-md-6">Pesan</label>
                            <div class="col-md-12">
                                <textarea class="form-control form-control-line" placeholder="Tulis pesan anda..." name="pesan" id="pesan"></textarea>
                            </div>
                        </div>
                        <div class="form-group m-t-40">
                            <div class="col-sm-12">
                                <button class="btn btn-success" onclick="ceksimpan()">Kirim pesan</button>
                            </div>
                        </div>
                    </div>
                </div>
                    
                    
            </div>
        </div>
    </div>
</div>
<!-- ============================================================== -->
<!-- End Container fluid  -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- footer -->
<!-- ============================================================== -->
<footer class="footer text-center">
    All Rights Reserved by Xtreme Admin. Designed and Developed by <a href="https://wrappixel.com">WrapPixel</a>.
</footer>
<!-- ============================================================== -->
<!-- End footer -->
<!-- ============================================================== -->

<script type="text/javascript">
    
    function ceksimpan(){
        var pesan = $("#pesan").val();
        var penerima = "<?php echo $this->uri->segment(4);?>";
        
        if (pesan == "") {
            swal("Informasi!", "Silahkan lengkapi data pengguna!", "warning");
        }else{
            $.ajax({
                url : "<?php echo site_url('usercontrol/simpan_chatting');?>",
                type : "POST",
                dataType : "json",
                data : {
                    pesan : pesan,
                    penerima : penerima
                },
                success:function(hasil){
                    if (hasil.hasil == 'berhasil') {
                        swal({
                            title: "Berhasil!",
                            text: "Data berhasil tersimpan !",
                            type: "success"
                        }).then(function() {
                            window.location='<?php echo base_url();?>usercontrol/homepage/detail_chat/<?php echo $this->uri->segment(4);?>';
                        });
                    }else{
                        swal("Kirim pesan gagal", "Silahkan cek kembali pesan anda!", "error");
                    }
                }
            });
        }
    }

</script>