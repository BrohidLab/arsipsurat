<!-- Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<div class="page-breadcrumb">
    <div class="row align-items-center">
        <div class="col-5">
            <h4 class="page-title">Tambah Pengguna</h4>
            <div class="d-flex align-items-center">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Pengaturan</li>
                        <li class="breadcrumb-item active" aria-current="page">Tambah Pengguna</li>
                    </ol>
                </nav>
            </div>
        </div>

        <div class="col-7">
            <div class="text-right upgrade-btn">
                <a href="<?php echo base_url();?>usercontrol/homepage/pengguna" class="btn btn-danger text-white"><i class="mdi mdi-keyboard-return"></i> Kembali</a>
            </div>
        </div>
    </div>
</div>
<!-- ============================================================== -->
<!-- End Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- Container fluid  -->
<!-- ============================================================== -->
<div class="container-fluid">
    <div class="row">
		<div class="col-10">
	        <div class="card">
	            <div class="card-body">
	                <h4 class="card-title">Data Pengguna</h4>
	                <h6 class="card-subtitle">Masukkan data dengan benar dan.</h6>
	            </div>
	            	
	            <div class="card-body">
                    <div class="form-horizontal form-material">
                        <div class="form-group">
                            <label class="col-md-6">Level Pengguna</label>
                            <div class="col-md-6">
                                <select id="level" class="form-control form-control-line">
                                    <option>Pilih</option>
                                    <option value="s_admin">Admin</option>
                                    <option value="user">User</option>
                                    <option value="manager">Manager</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="example-email" class="col-md-6">Nama Pengguna</label>
                            <div class="col-md-12">
                                <input type="text" placeholder="Masukkan nama pengguna" class="form-control form-control-line" name="nama_pengguna" id="nama_pengguna">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-12">Kata Sandi</label>
                            <div class="col-md-12">
                                <input type="password" placeholder="Masukkan kata sandi" id="password" class="form-control form-control-line">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-12">Ulangi Kata Sandi</label>
                            <div class="col-md-12">
                                <input type="password" placeholder="Ulangi kata sandi" id="ulangpass" class="form-control form-control-line">
                            </div>
                        </div>
                        <div class="form-group m-t-40">
                            <div class="col-sm-12">
                                <button class="btn btn-success" onclick="ceksimpan()">Simpan</button>
                            </div>
                        </div>
                    </div>
                </div>
	        </div>
	    </div>
	</div>
</div>
<!-- ============================================================== -->
<!-- End Container fluid  -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- footer -->
<!-- ============================================================== -->
<footer class="footer text-center">
    All Rights Reserved by Xtreme Admin. Designed and Developed by <a href="https://wrappixel.com">WrapPixel</a>.
</footer>
<!-- ============================================================== -->
<!-- End footer -->
<!-- ============================================================== -->

<script type="text/javascript">
	
	function ceksimpan(){
		var level = $("#level").val();
		var nama_pengguna = $("#nama_pengguna").val();
		var password = $("#password").val();
		var ulangpass = $("#ulangpass").val();
		if (level == "Pilih" || nama_pengguna == "" || password == "" || ulangpass == "") {
			swal("Informasi!", "Silahkan lengkapi data pengguna!", "warning");
		}else if (password != ulangpass) {
			swal("Informasi!", "Maaf kata sandi & ulangi kata sandi anda tidak cocok!", "warning");
		}else{
			$.ajax({
				url : "<?php echo site_url('usercontrol/simpan_pengguna');?>",
				type : "POST",
				dataType : "json",
				data : {
					level : level,
					nama_pengguna : nama_pengguna,
					password : password
				},
				success:function(hasil){
					if (hasil.hasil == 'berhasil') {
						swal({
						    title: "Berhasil!",
						    text: "Data berhasil tersimpan !",
						    type: "success"
						}).then(function() {
						    window.location='<?php echo base_url();?>usercontrol/homepage/tambahpengguna';
						});
					}else{
						swal("Login Gagal", "Silahkan cek kembali data pengguna!", "error");
					}
				}
			});
		}
	}

</script>