<!-- Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<div class="page-breadcrumb">
    <div class="row align-items-center">
        <div class="col-5">
            <h4 class="page-title">Tambah Memo</h4>
            <div class="d-flex align-items-center">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Pengaturan</li>
                        <li class="breadcrumb-item active" aria-current="page">Tambah Memo</li>
                    </ol>
                </nav>
            </div>
        </div>

        <div class="col-7">
            <div class="text-right upgrade-btn">
                <a href="<?php echo base_url();?>usercontrol/homepage/memo" class="btn btn-danger text-white"><i class="mdi mdi-keyboard-return"></i> Kembali</a>
            </div>
        </div>
    </div>
</div>
<!-- ============================================================== -->
<!-- End Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- Container fluid  -->
<!-- ============================================================== -->
<div class="container-fluid">
    <div class="row">
		<div class="col-10">
	        <div class="card">
	            <div class="card-body">
	                <h4 class="card-title">Data Memo</h4>
	                <h6 class="card-subtitle">Masukkan data dengan benar dan lengkap.</h6>
	            </div>
	            	
	            <div class="card-body">
                    <div class="form-horizontal form-material">
                        <div class="form-group">
                            <label for="example-email" class="col-md-6">Judul Memo</label>
                            <div class="col-md-12">
                                <input type="text" placeholder="Masukkan judul memo" class="form-control form-control-line" name="judul_memo" id="judul_memo">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="example-email" class="col-md-6">Memo</label>
                            <div class="col-md-12">
                                <textarea class="form-control form-control-line" name="memo" id="memo"></textarea>
                            </div>
                        </div>
                        <div class="form-group m-t-40">
                            <div class="col-sm-12">
                                <button class="btn btn-success" onclick="ceksimpan()">Simpan</button>
                            </div>
                        </div>
                    </div>
                </div>
	        </div>
	    </div>
	</div>
</div>
<!-- ============================================================== -->
<!-- End Container fluid  -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- footer -->
<!-- ============================================================== -->
<footer class="footer text-center">
    All Rights Reserved by Xtreme Admin. Designed and Developed by <a href="https://wrappixel.com">WrapPixel</a>.
</footer>
<!-- ============================================================== -->
<!-- End footer -->
<!-- ============================================================== -->

<script type="text/javascript">
	
	function ceksimpan(){
		var judul_memo = $("#judul_memo").val();
		var memo = $("#memo").val();
		
		if (judul_memo == "" || memo == "") {
			swal("Informasi!", "Silahkan lengkapi data pengguna!", "warning");
		}else{
			$.ajax({
				url : "<?php echo site_url('usercontrol/simpan_memo');?>",
				type : "POST",
				dataType : "json",
				data : {
					judul_memo : judul_memo,
					memo : memo
				},
				success:function(hasil){
					if (hasil.hasil == 'berhasil') {
						swal({
						    title: "Berhasil!",
						    text: "Data berhasil tersimpan !",
						    type: "success"
						}).then(function() {
						    window.location='<?php echo base_url();?>usercontrol/homepage/memo';
						});
					}else{
						swal("Login Gagal", "Silahkan cek kembali data pengguna!", "error");
					}
				}
			});
		}
	}

</script>