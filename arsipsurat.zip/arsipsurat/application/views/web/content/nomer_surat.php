<!-- Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<div class="page-breadcrumb">
    <div class="row align-items-center">
        <div class="col-5">
            <h4 class="page-title">Nomer Surat</h4>
            <div class="d-flex align-items-center">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Pengaturan</li>
                        <li class="breadcrumb-item active" aria-current="page">Nomer Surat</li>
                    </ol>
                </nav>
            </div>
        </div>

        <div class="col-7">
            <div class="text-right upgrade-btn">
                <a href="<?php echo base_url();?>usercontrol/homepage/tambah_ns" class="btn btn-success text-white"><i class="mdi mdi-account-multiple-plus"></i> Tambah Data</a>
            </div>
        </div>
    </div>
</div>
<!-- ============================================================== -->
<!-- End Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- Container fluid  -->
<!-- ============================================================== -->
<div class="container-fluid">
    <div class="row">
		<div class="col-12">
	        <div class="card">
	            <div class="card-body">
	                <h4 class="card-title">Data Nomer Surat</h4>
	                <h6 class="card-subtitle">Masukkan data dengan benar dan lengkap.</h6>
	                <div class="col-12">
	            		<table id="example" class="table">
		                    <thead class="thead-light">
		                        <tr>
		                            <th scope="col">No.</th>
		                            <th scope="col">Nomer Surat</th>
		                            <th scope="col">Jenis Nomer Surat</th>
		                            <th scope="col">Tanggal</th>
		                            <th scope="col"></th>
		                        </tr>
		                    </thead>
		                    <tbody>
		                    	<?php
		                    		$no = 0;
		                    		foreach ($datans as $array) {
		                    			$no++;
		                    	?>
		                        <tr>
		                            <th scope="row"><?php echo $no;?></th>
		                            <td><?php echo $array->nomer_surat;?></td>
		                            <td>
		                            	<?php
		                            		 if ($array->jenis_ns == "sm") {
		                            		  	echo "<button class='btn btn-success'>Surat Masuk</button>";
		                            		 }else{
		                            		 	echo "<button class='btn btn-danger'>Surat Keluar</button>";
		                            		 }
		                            	?>
		                            		
		                            </td>
		                            <td><?php echo $array->tanggal;?></td>
		                            <td>
		                            	
		                            	<a href="<?php echo base_url();?>usercontrol/homepage/edit_ns/<?php echo $array->id_nomer_surat;?>" class="btn btn-success" title="Edit"><i class="mdi mdi-table-edit"></i></a>
		                            	<a onClick="javascript: return confirm('Apakah anda yakin ingin menghapusnya ??')" href="<?php echo site_url('usercontrol/delete_ns'); ?>/<?php echo $array->id_nomer_surat;?>"  class="btn btn-danger" title="Hapus"><i class="mdi mdi-delete"></i></a>
		                            </td>
		                        </tr>
		                    <?php } ?>
		                    </tbody>
		                </table>
	            	</div>
	            </div>
	            	
	                
	        </div>
	    </div>
	</div>
</div>
<!-- ============================================================== -->
<!-- End Container fluid  -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- footer -->
<!-- ============================================================== -->
<footer class="footer text-center">
    All Rights Reserved by Xtreme Admin. Designed and Developed by <a href="https://wrappixel.com">WrapPixel</a>.
</footer>
<!-- ============================================================== -->
<!-- End footer -->
<!-- ============================================================== -->

