<!-- Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<?php 
	$tanggal_awal = $this->uri->segment(4);
	$tanggal_akhir = $this->uri->segment(5);
?>
<div class="page-breadcrumb">
    <div class="row align-items-center">
        <div class="col-5">
            <h4 class="page-title">Laporan Surat Keluar</h4>
            <div class="d-flex align-items-center">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Laporan Surat Keluar</li>
                    </ol>
                </nav>
            </div>
        </div>

        <div class="col-7">
            <div class="text-right upgrade-btn">
                <a href="<?php echo base_url();?>usercontrol/cetak_sk/<?php echo $tanggal_awal;?>/<?php echo $tanggal_akhir;?>" class="btn btn-success text-white" target="_blank"><i class="mdi mdi-printer"></i> Cetak</a>
            </div>
        </div>
    </div>
</div>
<!-- ============================================================== -->
<!-- End Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- Container fluid  -->
<!-- ============================================================== -->
<div class="container-fluid">
    <div class="row">
		<div class="col-12">
	        <div class="card">
	            <div class="card-body">
	                <h4 class="card-title">Data Surat Keluar</h4>
	                <h6 class="card-subtitle">Masukkan data dengan benar dan.</h6>
	                <div class="col-12">
	            		<table id="example" class="table">
		                    <thead class="thead-light">
		                        <tr>
		                            <th scope="col">No.</th>
		                            <th scope="col">No. Surat</th>
		                            <th scope="col">Tanggal Surat</th>
		                            <th scope="col">Perihal</th>
		                            <th scope="col">Status</th>
		                        </tr>
		                    </thead>
		                    <tbody>
		                    	<?php
		                    		$no = 0;
		                    		foreach ($datasm as $array) {
		                    			$no++;
		                    	?>
		                        <tr>
		                            <th scope="row"><?php echo $no;?></th>
		                            <td><?php echo $array->no_surat;?></td>
		                            <td><?php echo $array->tgl_ns;?></td>
		                            <td><?php echo $array->perihal;?></td>
		                            <td>
		                            	<?php
		                            		if ($array->dibaca == "Belum di baca") {
		                            	?>
		                            	<button class="btn btn-warning">Belum di baca</button>
		                            	<?php
		                            		}else if ($array->dibaca == "Sudah di baca") {
		                            	?>
		                            	<button class="btn btn-info">Sudah di baca</button>
		                            	<?php
		                            		}else{
		                            	?>
		                            	<button class="btn btn-success">Sudah di Approve</button>
		                            	<?php
		                            		}
		                            	?>
		                            </td>
		                        </tr>
		                    <?php } ?>
		                    </tbody>
		                </table>
	            	</div>
	            </div>
	            	
	                
	        </div>
	    </div>
	</div>
</div>
<!-- ============================================================== -->
<!-- End Container fluid  -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- footer -->
<!-- ============================================================== -->
<footer class="footer text-center">
    All Rights Reserved by Xtreme Admin. Designed and Developed by <a href="https://wrappixel.com">WrapPixel</a>.
</footer>
<!-- ============================================================== -->
<!-- End footer -->
<!-- ============================================================== -->

