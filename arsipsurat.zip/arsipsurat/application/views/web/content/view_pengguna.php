<!-- Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<div class="page-breadcrumb">
    <div class="row align-items-center">
        <div class="col-5">
            <h4 class="page-title">Data Pengguna</h4>
            <div class="d-flex align-items-center">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Pengaturan</li>
                        <li class="breadcrumb-item active" aria-current="page">Data Pengguna</li>
                    </ol>
                </nav>
            </div>
        </div>

        <div class="col-7">
            <div class="text-right upgrade-btn">
                <a href="<?php echo base_url();?>usercontrol/homepage/pengguna" class="btn btn-danger text-white"><i class="mdi mdi-keyboard-return"></i> Kembali</a>
            </div>
        </div>
    </div>
</div>
<!-- ============================================================== -->
<!-- End Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- Container fluid  -->
<!-- ============================================================== -->
<div class="container-fluid">
    <div class="row">
		<div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <center class="m-t-30"> <img src="<?php echo base_url();?>assets/assets_home/images/users/d3.jpg" class="rounded-circle" width="150">
                        <h4 class="card-title m-t-10"><?php echo $arrayuser['nama_lengkap'];?></h4>
                        <h6 class="card-subtitle"><?php echo $arrayuser['username'];?></h6>
                    </center>
                </div>
                <div>
                    <hr> </div>
                <div class="card-body"> 
                    <small class="text-muted">Email address </small>
                    <h6><?php echo $arrayuser['email'];?></h6> 
                    <small class="text-muted p-t-30 db">Phone</small>
                    <h6><?php echo $arrayuser['telp'];?></h6> 
                    <small class="text-muted p-t-30 db">Address</small>
                    <h6><?php echo $arrayuser['alamat'];?></h6> 
                    <small class="text-muted p-t-30 db">Pengalaman</small>
                    <h6><?php echo $arrayuser['pengalaman'];?></h6>
                </div>
            </div>
        </div>
	</div>
</div>
<!-- ============================================================== -->
<!-- End Container fluid  -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- footer -->
<!-- ============================================================== -->
<footer class="footer text-center">
    All Rights Reserved by Xtreme Admin. Designed and Developed by <a href="https://wrappixel.com">WrapPixel</a>.
</footer>
<!-- ============================================================== -->
<!-- End footer -->
<!-- ============================================================== -->

