<?php
    $dataview = $this->uri->segment(5);
    $id = $this->uri->segment(4);
    if (empty($dataview)) {
        $title = "Edit Surat Keluar";
    }else{
        $title = "Detail Surat Keluar";
        $this->db->query("UPDATE tbl_sk set dibaca = 'Sudah di baca' where id_sk = '$id'");
    }
?>
<!-- Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<script src="<?php echo base_url();?>assets/assets_home/dist/js/select2.min.js"></script>
<script src="<?php echo base_url();?>assets/assets_home/dist/js/jquery-ui.js"></script>

<div class="page-breadcrumb">
    <div class="row align-items-center">
        <div class="col-5">
            <h4 class="page-title"><?php echo $title;?></h4>
            <div class="d-flex align-items-center">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo $title;?></li>
                    </ol>
                </nav>
            </div>
        </div>

        <div class="col-7">
            <div class="text-right upgrade-btn">
                <a href="<?php echo base_url();?>usercontrol/homepage/s_keluar" class="btn btn-danger text-white"><i class="mdi mdi-keyboard-return"></i> Kembali</a>
            </div>
        </div>
    </div>
</div>
<!-- ============================================================== -->
<!-- End Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- Container fluid  -->
<!-- ============================================================== -->
<div class="container-fluid">
    <div class="row">
		<div class="col-10">
	        <div class="card">
	            <div class="card-body">
	                <h4 class="card-title"><?php echo $title;?></h4>
	                <h6 class="card-subtitle">Masukkan data dengan benar dan.</h6>
	            </div>
	            	
	            <div class="card-body">
                    <div class="form-horizontal form-material">
                        <?php echo form_open_multipart('usercontrol/edits_keluar');?>
                        <div class="form-group">
                            <label class="col-md-6">No. Surat Keluar</label>
                            <div class="col-md-6">
                                <input type="text" placeholder="No. Surat Keluar" value="<?php echo $arraysurat['no_surat'];?>" class="form-control form-control-line" name="no_surat_keluar" id="surat_keluar">
                                <input type="hidden" placeholder="No. Surat Keluar" value="<?php echo $this->uri->segment(4);?>" class="form-control form-control-line" name="id_skeluar" id="id_skeluar">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="example-email" class="col-md-6">Tanggal</label>
                            <div class="col-md-6">
                                <input type="date" placeholder="Masukkan nama pengguna" class="form-control form-control-line" value="<?php echo $arraysurat['tgl_ns'];?>" name="tgl_no_asal" id="tgl_no_asal">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-12">Perihal</label>
                            <div class="col-md-12">
                                <input type="text" name="perihal" value="<?php echo $arraysurat['perihal'];?>" class="form-control form-control-line">
                            </div>
                        </div>
                        <div class="form-group">
                          <label class="control-label col-lg-3">Penerima</label>
                          <div class="col-lg-9">
                                <select class="form-control cari_penerima" name="penerima" id="penerima" required>
                                  <option value="">Pilih</option>
                                  <?php
                                  $this->db->order_by('nama_lengkap', 'ASC');
                                        foreach ($this->db->get('tbl_user')->result() as $baris): ?>
                                            <option <?php if($arraysurat['penerima'] == $baris->nama_lengkap) echo "selected";?> value="<?php echo $baris->nama_lengkap; ?>"><?php echo $baris->nama_lengkap; ?></option>
                                  <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-12">*Lampiran</label>
                            <div class="col-md-12">
                            <hr/>
                                <span class="title"><?php echo $arraysurat['token_lampiran'];?></span> &nbsp;&nbsp;&nbsp;<a href="<?php echo base_url();?>assets/lampiran_surat_keluar/<?php echo $arraysurat['token_lampiran'];?>" target="_blank"><i class="mdi mdi-export"></i></a>
                            </div>
                        </div>
                        <?php
                            if (empty($dataview)) {
                        ?>
                            <div class="form-group m-t-40">
                                <div class="col-sm-12">
                                    <button class="btn btn-success" type="submit">Simpan</button>
                                </div>
                            </div>
                        <?php
                            }
                        ?>
                        
                        <?php echo form_close();?>
                    </div>
                </div>
	        </div>
	    </div>
	</div>
</div>
<!-- ============================================================== -->
<!-- End Container fluid  -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- footer -->
<!-- ============================================================== -->
<footer class="footer text-center">
    All Rights Reserved by Xtreme Admin. Designed and Developed by <a href="https://wrappixel.com">WrapPixel</a>.
</footer>
<!-- ============================================================== -->
<!-- End footer -->
<!-- ============================================================== -->
