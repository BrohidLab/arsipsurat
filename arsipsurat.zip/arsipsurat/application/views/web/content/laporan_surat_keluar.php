<!-- Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<div class="page-breadcrumb">
    <div class="row align-items-center">
        <div class="col-5">
            <h4 class="page-title">Laporan Surat Keluar</h4>
            <div class="d-flex align-items-center">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Laporan Surat Keluar</li>
                    </ol>
                </nav>
            </div>
        </div>

    </div>
</div>
<!-- ============================================================== -->
<!-- End Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- Container fluid  -->
<!-- ============================================================== -->
<div class="container-fluid">
    <div class="row">
		<div class="col-7">
	        <div class="card">
	            <div class="card-body">
                    <div class="form-horizontal form-material">
                        <div class="form-group">
                            <label class="col-md-6">Dari Tanggal</label>
                            <div class="col-md-12">
                                <input type="date" placeholder="No. Surat Masuk" class="form-control" name="no_surat_masuk" id="tanggal_awal">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="example-email" class="col-md-6">Sampai Tanggal</label>
                            <div class="col-md-12">
                                <input type="date" placeholder="Masukkan nama pengguna" class="form-control form-control-line" name="tgl_no_asal" id="tgl_akhir">
                            </div>
                        </div>
                        <div class="form-group m-t-40">
                            <div class="col-sm-12">
                                <button class="btn btn-success" onclick="cari()">Cari</button>
                            </div>
                        </div>
                    </div>
                </div>
	        </div>
	    </div>
	</div>
</div>
<!-- ============================================================== -->
<!-- End Container fluid  -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- footer -->
<!-- ============================================================== -->
<footer class="footer text-center">
    All Rights Reserved by Xtreme Admin. Designed and Developed by <a href="https://wrappixel.com">WrapPixel</a>.
</footer>
<!-- ============================================================== -->
<!-- End footer -->
<!-- ============================================================== -->

<script type="text/javascript">
	
	function cari(){
		var tanggal_awal = $("#tanggal_awal").val();
        var tanggal_akhir = $("#tgl_akhir").val();

        document.location.href = "<?php echo base_url();?>usercontrol/homepage/view_laporan_surat_keluar/"+tanggal_awal+"/"+tanggal_akhir;
	}
</script>