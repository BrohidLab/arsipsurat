<!-- ============================================================== -->
<!-- Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<div class="page-breadcrumb">
    <div class="row align-items-center">
        <div class="col-5">
            <h4 class="page-title">Dashboard</h4>
            <div class="d-flex align-items-center">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Library</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>
<!-- ============================================================== -->
<!-- End Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- Container fluid  -->
<!-- ============================================================== -->
<div class="container-fluid">
    <!-- ============================================================== -->
    <!-- Sales chart -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <div class="row">
        <!-- column -->
        <div class="col-lg-4">
            <div class="card">
                <div class="comment-widgets scrollable">
                    <!-- Comment Row -->
                    <div class="d-flex flex-row comment-row m-t-0">
                        <div class="p-2"><img src="<?php echo base_url();?>assets/assets_home/images/users/1.jpg" alt="user" width="50" class="rounded-circle"></div>
                        <br/>
                        <div class="comment-text" style="color: rgb(136,136,136);">
                            <h2 class="page-title"><?php echo $jumlah_userdata;?></h2>
                            <span class="m-b-25 font-medium" style="font-family: segoe ui; font-size: 16px;">Data User</span>  
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="col-lg-4">
            <div class="card">
                <div class="comment-widgets scrollable">
                    <!-- Comment Row -->
                    <div class="d-flex flex-row comment-row m-t-0">
                        <div class="p-2"><img src="<?php echo base_url();?>assets/assets_home/images/users/email.png" alt="user" width="50" class="rounded-circle"></div>
                        <br/>
                        <div class="comment-text" style="color: rgb(136,136,136);">
                            <h2 class="page-title"><?php echo $jumlah_smasuk;?></h2>
                            <span class="m-b-25 font-medium" style="font-family: segoe ui; font-size: 16px;">Surat Masuk</span>  
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="col-lg-4">
            <div class="card">
                <div class="comment-widgets scrollable">
                    <!-- Comment Row -->
                    <div class="d-flex flex-row comment-row m-t-0">
                        <div class="p-2"><img src="<?php echo base_url();?>assets/assets_home/images/users/sending.png" alt="user" width="50" class="rounded-circle"></div>
                        <br/>
                        <div class="comment-text" style="color: rgb(136,136,136);">
                            <h2 class="page-title"><?php echo $jumlah_skeluar;?></h2>
                            <span class="m-b-25 font-medium" style="font-family: segoe ui; font-size: 16px;">Surat Keluar</span>  
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Informasi !</h4><hr/>
                    <span class="m-b-15 d-block">Silahkan gunakan aplikasi ini dengan benar dan sesuai peraturannya. </span>
                </div>
            </div>
        </div>

        <!-- column -->
    </div>
    <!-- ============================================================== -->
    <!-- Recent comment and chats -->
    <!-- ============================================================== -->
</div>
<!-- ============================================================== -->
<!-- End Container fluid  -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- footer -->
<!-- ============================================================== -->
<footer class="footer text-center">
    All Rights Reserved by Xtreme Admin. Designed and Developed by <a href="https://wrappixel.com">WrapPixel</a>.
</footer>
<!-- ============================================================== -->
<!-- End footer -->
<!-- ============================================================== -->