<?php

   	$user = $this->session->userdata('nama');
    if (!empty($user)) {
        redirect('usercontrol','refresh');
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Aplikasi Document Arsip</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="<?php echo base_url();?>assets/assets_login_new/images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/assets_login_new/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/assets_login_new/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/assets_login_new/vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/assets_login_new/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/assets_login_new/vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/assets_login_new/css/util.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/assets_login_new/css/main.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/assets_login_new/css/custom.css">
<!--===============================================================================================-->

</head>
<body>
	<noscript>
		<div class="notification">
			<div class="pesan">
				Mohon aktifkan javascript anda pada browser anda, terima kasih.
			</div>
		</div>
	</noscript>
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<div class="login100-pic js-tilt" data-tilt>
					<img src="<?php echo base_url();?>assets/assets_login_new/images/img-01.png" alt="IMG">
				</div>

				<div class="login100-form validate-form" >
					<span class="login100-form-title">
						<img src="<?php echo base_url();?>assets/foto/logo.png" width="120" height="100" style="margin-bottom: 15px;"><br/>
						Login Document Arsip
					</span>
					<div class="wrap-input100 validate-input" data-validate = "Username is required">
						<input class="input100" type="text" name="username" id="username" placeholder="Username">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-user" aria-hidden="true"></i>
						</span>
					</div>

					<div class="wrap-input100 validate-input" data-validate = "Password is required">
						<input class="input100" type="password" name="password" id="password" placeholder="Password">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-lock" aria-hidden="true"></i>
						</span>
					</div>
					
					<div class="container-login100-form-btn">
						<button onclick="login()" class="login100-form-btn">
							Login
						</button>
					</div>
					<div class="text-center p-t-136">
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<div class="loading-page">
		<center>
			<div class="icon-logo">
			</div>
		</center>
		<div class="sk-cube-grid">
			<div class="sk-cube sk-cube1"></div>
			<div class="sk-cube sk-cube2"></div>
			<div class="sk-cube sk-cube3"></div>
			<div class="sk-cube sk-cube4"></div>
			<div class="sk-cube sk-cube5"></div>
			<div class="sk-cube sk-cube6"></div>
			<div class="sk-cube sk-cube7"></div>
			<div class="sk-cube sk-cube8"></div>
			<div class="sk-cube sk-cube9"></div>
		</div>
		<center>
			<span>Loading . . .</span>
		</center>

	</div>
	


	
<!--===============================================================================================-->	
	<script src="<?php echo base_url();?>assets/assets_login_new/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="<?php echo base_url();?>assets/assets_login_new/vendor/bootstrap/js/popper.js"></script>
	<script src="<?php echo base_url();?>assets/assets_login_new/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="<?php echo base_url();?>assets/assets_login_new/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="<?php echo base_url();?>assets/assets_login_new/vendor/tilt/tilt.jquery.min.js"></script>

	
	<script src="<?php echo base_url();?>assets/assets_login_new/js/sweetalert.js"></script>

<!--===============================================================================================--> 
	<script src="//cdn.ckeditor.com/4.10.1/standard/ckeditor.js"></script>	
<!--===============================================================================================-->
	<script type="text/javascript">
		
		function login(){
			$.ajax({
				url : "<?php echo site_url('proses_login/proses_login');?>",
				type : "POST",
				dataType : "json",
				data : {
					username : $("#username").val(),
					password : $("#password").val()
				}, 
				success:function(hasil){
					if (hasil.hasil == 'berhasil') {
						swal({
						    title: "Berhasil!",
						    text: "Selamat Datang !",
						    type: "success"
						}).then(function() {
						    window.location='usercontrol/homepage';
						});
					}else{
						swal("Login Gagal", "Silahkan cek kembali username & password anda!", "error");
					}
				}
			});
		}

	</script>

	<script >
		$('.js-tilt').tilt({
			scale: 1.1
		})
	</script>

	<script type="text/javascript">
		var waktu = 3;
		setInterval(function() {
			waktu--;
			if(waktu < 0) {
				$(".loading-page").fadeOut(1500);
			}
		}, 1000);

	</script>
<!--===============================================================================================-->
	<script src="<?php echo base_url();?>assets/assets_login_new/js/main.js"></script>

<!--===============================================================================================-->

	<script language="JavaScript">
	document.onkeydown = function(e) {
	if (e.ctrlKey && 
	(e.keyCode === 67 || 
	e.keyCode === 86 || 
	e.keyCode === 85 || 
	e.keyCode === 117)) {return false;}else{return true;}};
	window.oncontextmenu = function () {return false;}
	$(document).keydown(function (event) {
	if (event.keyCode == 123) {
	return false;}else if ((event.ctrlKey && event.shiftKey && event.keyCode == 73) || (event.ctrlKey && event.shiftKey && event.keyCode == 74)) {return false;}});
	</script>

</body>
</html>